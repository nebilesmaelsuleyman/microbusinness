/* ==========================================================================
   API client — typed wrapper over the NestJS backend (global prefix /api).
   ========================================================================== */

const API_BASE = import.meta.env.VITE_API_URL || '/api';
const TOKEN_KEY = 'microbusiness_token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export async function api<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const msg = Array.isArray(data?.message) ? data.message.join(', ') : data?.message || data?.error;
    throw new ApiError(msg || `Request failed (${res.status})`, res.status);
  }
  return data as T;
}

const qs = (params: Record<string, unknown>): string => {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v != null && v !== '') q.set(k, String(v));
  });
  const s = q.toString();
  return s ? `?${s}` : '';
};

/* ------------------------------------------------------------------- Types */

export type Role = 'customer' | 'provider' | 'admin';
export type JobStatus = 'requested' | 'accepted' | 'rejected' | 'completed' | 'cancelled';
export type VerificationStatus = 'pending' | 'approved' | 'rejected';
export type PricingModel = 'fixed' | 'hourly' | 'quote';

export interface GeoLocation {
  latitude: number;
  longitude: number;
}

export interface AuthUser {
  id: string;
  phoneNumber: string;
  name: string;
  role: Role;
  profilePhoto?: string | null;
  location?: GeoLocation | null;
}

export interface User {
  _id: string;
  phoneNumber: string;
  name: string;
  role: Role;
  profilePhoto?: string | null;
  location?: GeoLocation | null;
  createdAt?: string;
}

export interface Category {
  _id: string;
  name: string;
  description?: string;
}

/** userId may be a raw id or a populated user object depending on endpoint. */
export type PopulatedUser = string | {
  _id: string;
  name?: string;
  phoneNumber?: string;
  profilePhoto?: string | null;
  location?: GeoLocation | null;
};

export interface ProviderProfile {
  _id: string;
  userId: PopulatedUser;
  serviceCategories: Category[] | string[];
  serviceDescription: string;
  yearsOfExperience: number;
  serviceRadiusKm: number;
  pricingModel: PricingModel;
  availabilitySchedule?: Record<string, unknown>;
  verificationStatus: VerificationStatus;
  ratingAverage: number;
  reviewCount: number;
  coordinates?: { type: 'Point'; coordinates: [number, number] };
  createdAt?: string;
}

export interface VerificationDocument {
  _id: string;
  providerId: string;
  documentType: string;
  documentUrl: string;
  status: VerificationStatus;
  uploadedAt: string;
}

export interface Job {
  _id: string;
  customerId: PopulatedUser;
  providerId: string | { _id?: string; userId?: PopulatedUser; serviceDescription?: string };
  status: JobStatus;
  description?: string;
  scheduledDate?: string | null;
  createdAt: string;
}

export interface Lead {
  _id: string;
  customerId: PopulatedUser;
  providerId: string;
  createdAt: string;
}

export interface Review {
  _id: string;
  customerId: PopulatedUser;
  providerId: string;
  rating: number;
  comment?: string;
  createdAt: string;
}

export interface Favorite {
  _id: string;
  customerId: string;
  providerId: ProviderProfile | string;
  createdAt: string;
}

export interface SubscriptionPlan {
  _id: string;
  name: string;
  price: number;
  leadLimit: number;
  visibilityBoost: boolean;
  durationDays: number;
}

export interface ProviderSubscription {
  _id: string;
  providerId: string;
  planId: SubscriptionPlan | string;
  startDate: string;
  endDate: string;
  leadUsed: number;
}

export interface JobStats {
  [status: string]: number;
}

export interface RevenueMetrics {
  totalSubscriptions: number;
  totalRevenue: number;
  activeSubscriptions: number;
}

/* ----------------------------------------------------------------- Auth API */

export const authApi = {
  sendOtp: (phoneNumber: string) =>
    api<{ message: string; devOtp?: string }>('/auth/send-otp', {
      method: 'POST',
      body: JSON.stringify({ phoneNumber }),
    }),
  verifyOtp: (body: { phoneNumber: string; otp: string; name?: string; role?: Role }) =>
    api<{ access_token: string; user: AuthUser }>('/auth/verify-otp', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
};

/* ---------------------------------------------------------------- Users API */

export const usersApi = {
  me: () => api<User>('/users/me'),
  updateMe: (body: { name?: string; profilePhoto?: string; location?: GeoLocation }) =>
    api<User>('/users/me', { method: 'PATCH', body: JSON.stringify(body) }),
  byId: (id: string) => api<User>(`/users/${id}`),
};

/* ------------------------------------------------------------ Categories API */

export const categoriesApi = {
  list: () => api<Category[]>('/categories'),
  one: (id: string) => api<Category>(`/categories/${id}`),
};

/* ------------------------------------------------------------- Providers API */

export interface SearchParams {
  categoryId?: string;
  latitude?: number;
  longitude?: number;
  maxDistanceKm?: number;
  minRating?: number;
  limit?: number;
  skip?: number;
}

export interface ProviderProfileInput {
  serviceCategories?: string[];
  serviceDescription?: string;
  yearsOfExperience?: number;
  serviceRadiusKm?: number;
  pricingModel?: PricingModel;
  latitude?: number;
  longitude?: number;
}

export const providersApi = {
  search: (params: SearchParams) => api<ProviderProfile[]>(`/providers/search${qs({ ...params })}`),
  getProfile: (userId: string) => api<ProviderProfile>(`/providers/${userId}/profile`),
  getMyProfile: () => api<ProviderProfile | null>('/providers/profile/me').catch(() => null),
  createProfile: (body: ProviderProfileInput) =>
    api<ProviderProfile>('/providers/profile', { method: 'POST', body: JSON.stringify(body) }),
  updateProfile: (body: ProviderProfileInput) =>
    api<ProviderProfile>('/providers/profile', { method: 'PATCH', body: JSON.stringify(body) }),
  uploadDocument: (body: { documentType: string; documentUrl: string }) =>
    api<VerificationDocument>('/providers/verification-documents', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  myDocuments: () => api<VerificationDocument[]>('/providers/verification-documents/me'),
};

/* ---------------------------------------------------------------- Jobs API */

export const jobsApi = {
  myList: () => api<Job[]>('/jobs/me/list'),
  one: (id: string) => api<Job>(`/jobs/${id}`),
  create: (body: { providerId: string; description?: string; scheduledDate?: string }) =>
    api<Job>('/jobs', { method: 'POST', body: JSON.stringify(body) }),
  updateStatus: (id: string, status: JobStatus) =>
    api<Job>(`/jobs/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
};

/* ---------------------------------------------------------------- Leads API */

export const leadsApi = {
  contact: (providerId: string) =>
    api<{ phoneNumber: string; lead: Lead }>('/leads/contact', {
      method: 'POST',
      body: JSON.stringify({ providerId }),
    }),
  myLeads: () => api<Lead[]>('/leads/my-leads'),
};

/* -------------------------------------------------------------- Reviews API */

export const reviewsApi = {
  byProvider: (providerId: string) => api<Review[]>(`/reviews/provider/${providerId}`),
  create: (providerId: string, body: { rating: number; comment?: string }) =>
    api<Review>(`/reviews/provider/${providerId}`, { method: 'POST', body: JSON.stringify(body) }),
};

/* ------------------------------------------------------------ Favorites API */

export const favoritesApi = {
  list: () => api<Favorite[]>('/favorites'),
  add: (providerId: string) =>
    api<Favorite>('/favorites', { method: 'POST', body: JSON.stringify({ providerId }) }),
  remove: (providerId: string) =>
    api<{ deleted: boolean }>(`/favorites/${providerId}`, { method: 'DELETE' }),
};

/* -------------------------------------------------------- Subscriptions API */

export const subscriptionsApi = {
  plans: () => api<SubscriptionPlan[]>('/subscriptions/plans'),
  subscribe: (planId: string) =>
    api<ProviderSubscription>('/subscriptions/subscribe', {
      method: 'POST',
      body: JSON.stringify({ planId }),
    }),
  me: () => api<ProviderSubscription | null>('/subscriptions/me').catch(() => null),
};

/* ---------------------------------------------------------------- Admin API */

export const adminApi = {
  users: (params: { skip?: number; limit?: number } = {}) =>
    api<User[]>(`/admin/users${qs({ ...params })}`),
  providers: (params: { skip?: number; limit?: number } = {}) =>
    api<ProviderProfile[]>(`/admin/providers${qs({ ...params })}`),
  verifyProvider: (providerId: string, status: 'approved' | 'rejected') =>
    api<ProviderProfile>(`/admin/providers/${providerId}/verify`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
  verificationDocuments: () => api<VerificationDocument[]>('/admin/verification-documents'),
  setDocumentStatus: (docId: string, status: 'approved' | 'rejected') =>
    api<VerificationDocument>(`/admin/verification-documents/${docId}`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
  categories: () => api<Category[]>('/admin/categories'),
  createCategory: (body: { name: string; description?: string }) =>
    api<Category>('/admin/categories', { method: 'POST', body: JSON.stringify(body) }),
  updateCategory: (id: string, body: { name?: string; description?: string }) =>
    api<Category>(`/admin/categories/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  jobStats: () => api<JobStats>('/admin/stats/jobs'),
  revenue: () => api<RevenueMetrics>('/admin/stats/revenue'),
  createPlan: (body: {
    name: string;
    price: number;
    leadLimit: number;
    visibilityBoost: boolean;
    durationDays: number;
  }) => api<SubscriptionPlan>('/admin/plans', { method: 'POST', body: JSON.stringify(body) }),
};
