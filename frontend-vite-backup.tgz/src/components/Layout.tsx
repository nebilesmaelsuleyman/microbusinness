import { useState, useRef, useEffect } from 'react';
import { Outlet, Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Avatar } from './ui';
import {
  IconBolt, IconBriefcase, IconHeart, IconLayout, IconShield,
  IconUser, IconSettings, IconLogout, IconChevronDown, IconSearch,
} from './icons';

function UserMenu() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  if (!user) return null;

  const go = (path: string) => { setOpen(false); navigate(path); };

  return (
    <div className="usermenu" ref={ref}>
      <button className="usermenu-btn" onClick={() => setOpen((o) => !o)}>
        <Avatar name={user.name || 'U'} src={user.profilePhoto} size="sm" />
        <IconChevronDown style={{ width: 15, height: 15 }} />
      </button>
      {open && (
        <div className="usermenu-pop">
          <div className="usermenu-head">
            <div className="name">{user.name || 'Welcome'}</div>
            <div className="role">{user.role}</div>
          </div>
          {user.role === 'customer' && (
            <>
              <button className="mi" onClick={() => go('/my-jobs')}><IconBriefcase /> My jobs</button>
              <button className="mi" onClick={() => go('/favorites')}><IconHeart /> Saved providers</button>
            </>
          )}
          {user.role === 'provider' && (
            <>
              <button className="mi" onClick={() => go('/dashboard')}><IconLayout /> Dashboard</button>
              <button className="mi" onClick={() => go('/dashboard/profile')}><IconUser /> My profile</button>
            </>
          )}
          {user.role === 'admin' && (
            <button className="mi" onClick={() => go('/admin')}><IconShield /> Admin panel</button>
          )}
          <button className="mi" onClick={() => go('/account')}><IconSettings /> Account settings</button>
          <button className="mi" onClick={() => { logout(); navigate('/login'); }}><IconLogout /> Sign out</button>
        </div>
      )}
    </div>
  );
}

export default function Layout() {
  const { user, token } = useAuth();

  return (
    <div className="layout">
      <header className="header">
        <div className="header-inner">
          <Link to="/" className="logo">
            <span className="logo-mark"><IconBolt /></span>
            Servio
          </Link>

          <nav className="nav">
            <NavLink to="/" end className="nav-link"><IconSearch /> Find services</NavLink>

            {token && user?.role === 'customer' && (
              <>
                <NavLink to="/my-jobs" className="nav-link"><IconBriefcase /> My jobs</NavLink>
                <NavLink to="/favorites" className="nav-link"><IconHeart /> Saved</NavLink>
              </>
            )}
            {token && user?.role === 'provider' && (
              <NavLink to="/dashboard" className="nav-link"><IconLayout /> Dashboard</NavLink>
            )}
            {token && user?.role === 'admin' && (
              <NavLink to="/admin" className="nav-link"><IconShield /> Admin</NavLink>
            )}

            {token ? (
              <UserMenu />
            ) : (
              <Link to="/login" className="btn btn-primary btn-sm" style={{ marginLeft: 6 }}>Sign in</Link>
            )}
          </nav>
        </div>
      </header>

      <main className="main">
        <Outlet />
      </main>

      <footer className="footer">
        <div className="footer-inner">
          <span>© {new Date().getFullYear()} Servio — local services marketplace.</span>
          <span className="row gap-16">
            <span>Trusted local pros</span>
            <span>·</span>
            <span>Verified & reviewed</span>
          </span>
        </div>
      </footer>
    </div>
  );
}
