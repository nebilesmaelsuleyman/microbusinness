import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi, type Role } from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { Field } from '../components/ui';
import {
  IconBolt, IconShieldCheck, IconStar, IconBriefcase, IconUser, IconInfo, IconArrowRight, IconPhone,
} from '../components/icons';

type Step = 'phone' | 'verify';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();

  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [devOtp, setDevOtp] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [role, setRole] = useState<Role>('customer');
  const [loading, setLoading] = useState(false);

  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authApi.sendOtp(phone.trim());
      // In dev/test mode the backend returns the code so there's no SMS needed —
      // remember it to display, and prefill the input so the user can just submit.
      setDevOtp(res.devOtp ?? null);
      if (res.devOtp) setOtp(res.devOtp);
      setStep('verify');
      toast.success('Verification code sent');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not send code');
    } finally {
      setLoading(false);
    }
  };

  const verify = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authApi.verifyOtp({ phoneNumber: phone.trim(), otp, name: name.trim() || undefined, role });
      login(res.access_token, res.user);
      toast.success(`Welcome${res.user.name ? `, ${res.user.name}` : ''}!`);
      navigate(res.user.role === 'provider' ? '/dashboard' : res.user.role === 'admin' ? '/admin' : '/');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Invalid code');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrap">
      {/* Brand panel */}
      <aside className="auth-aside">
        <div className="aa-content">
          <div className="logo" style={{ color: '#fff' }}>
            <span className="logo-mark"><IconBolt /></span> Servio
          </div>
          <h2 style={{ marginTop: 48 }}>Hire trusted local <span className="accent">pros</span>, or grow your service business.</h2>
          <p>Join thousands of customers and providers on the marketplace built for local services.</p>
          <div className="auth-feat">
            {[
              { ic: <IconShieldCheck />, t: 'Verified providers', d: 'Every pro is ID & document verified.' },
              { ic: <IconStar />, t: 'Trusted reviews', d: 'Real ratings from real customers.' },
              { ic: <IconBriefcase />, t: 'Get hired faster', d: 'Receive job requests and leads directly.' },
            ].map((f) => (
              <div key={f.t} className="af">
                <span className="af-ic">{f.ic}</span>
                <div><b>{f.t}</b><div><span>{f.d}</span></div></div>
              </div>
            ))}
          </div>
        </div>
        <div className="aa-content small" style={{ opacity: 0.8 }}>© {new Date().getFullYear()} Servio</div>
      </aside>

      {/* Form panel */}
      <main className="auth-main">
        <div className="auth-card">
          {step === 'phone' ? (
            <>
              <h1>Welcome to Servio</h1>
              <p className="sub">Enter your phone number to sign in or create an account.</p>
              <form onSubmit={sendOtp}>
                <Field label="Phone number" hint="Use international format, e.g. +1234567890." htmlFor="phone">
                  <div className="input-icon">
                    <IconPhone />
                    <input id="phone" className="input" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1234567890" required autoFocus />
                  </div>
                </Field>
                <button className="btn btn-primary btn-block btn-lg" disabled={loading}>
                  {loading ? 'Sending…' : <>Continue <IconArrowRight /></>}
                </button>
              </form>
            </>
          ) : (
            <>
              <h1>Verify your number</h1>
              <p className="sub">We sent a code to <b>{phone}</b>.</p>
              {devOtp ? (
                <div className="otp-hint">
                  <IconInfo /> Test mode — your verification code is <b style={{ letterSpacing: '0.15em' }}>{devOtp}</b>. It's already filled in below, just press <b>Sign in</b>.
                </div>
              ) : (
                <div className="otp-hint"><IconInfo /> In development the code is logged to the backend console (test mode uses <b>1234</b>).</div>
              )}
              <form onSubmit={verify}>
                <Field label="Verification code" htmlFor="otp">
                  <input id="otp" className="input" inputMode="numeric" value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 8))}
                    placeholder="1234" required autoFocus style={{ letterSpacing: '0.3em', fontSize: 18, fontWeight: 600 }} />
                </Field>
                <Field label="Your name" hint="Helps providers and customers recognise you." htmlFor="name">
                  <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
                </Field>
                <Field label="I want to">
                  <div className="role-pick">
                    <button type="button" className={`role-opt${role === 'customer' ? ' sel' : ''}`} onClick={() => setRole('customer')}>
                      <span className="ro-ic"><IconUser /></span>
                      <b>Hire a pro</b>
                      <span>Find & book local services</span>
                    </button>
                    <button type="button" className={`role-opt${role === 'provider' ? ' sel' : ''}`} onClick={() => setRole('provider')}>
                      <span className="ro-ic"><IconBriefcase /></span>
                      <b>Offer services</b>
                      <span>Get jobs as a provider</span>
                    </button>
                  </div>
                </Field>
                <button className="btn btn-primary btn-block btn-lg" disabled={loading}>{loading ? 'Verifying…' : 'Sign in'}</button>
                <button type="button" className="btn btn-link btn-block mt-8" onClick={() => { setStep('phone'); setOtp(''); setDevOtp(null); }}>Use a different number</button>
              </form>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
