import { useState, useEffect, useCallback } from 'react';
import { categoriesApi, providersApi, type Category, type ProviderProfile, type SearchParams } from '../api/client';
import { useToast } from '../contexts/ToastContext';
import { useFavorites } from '../lib/useFavorites';
import ProviderCard from '../components/ProviderCard';
import ProvidersMap from '../components/ProvidersMap';
import { ProviderCardSkeleton, EmptyState } from '../components/ui';
import {
  IconSearch, IconMapPin, IconShieldCheck, IconStar, IconBolt, IconUsers, IconBriefcase,
} from '../components/icons';

export default function Home() {
  const toast = useToast();
  const fav = useFavorites();

  const [categories, setCategories] = useState<Category[]>([]);
  const [providers, setProviders] = useState<ProviderProfile[]>([]);
  const [categoryId, setCategoryId] = useState('');
  const [minRating, setMinRating] = useState('');
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [view, setView] = useState<'list' | 'map'>('list');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    categoriesApi.list().then(setCategories).catch(() => setCategories([]));
  }, []);

  const runSearch = useCallback(() => {
    setLoading(true);
    const params: SearchParams = { limit: 24 };
    if (categoryId) params.categoryId = categoryId;
    if (minRating) params.minRating = Number(minRating);
    if (coords) { params.latitude = coords.lat; params.longitude = coords.lng; params.maxDistanceKm = 50; }
    providersApi.search(params)
      .then(setProviders)
      .catch(() => setProviders([]))
      .finally(() => setLoading(false));
  }, [categoryId, minRating, coords]);

  useEffect(() => { runSearch(); }, [runSearch]);

  const useMyLocation = () => {
    if (!navigator.geolocation) { toast.error('Geolocation is not supported by your browser'); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocating(false);
        toast.success('Showing providers near you');
      },
      () => { setLocating(false); toast.error('Could not get your location'); },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="hero-inner">
          <h1>Find trusted local <span className="accent">pros</span> for any job</h1>
          <p>Browse verified service providers near you — compare ratings, message directly, and get the work done.</p>

          <div className="hero-search">
            <div className="input-icon grow">
              <IconSearch />
              <select className="select" value={categoryId} onChange={(e) => setCategoryId(e.target.value)} aria-label="Service category">
                <option value="">All services</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
            </div>
            <div className="divider" />
            <button className={`btn ${coords ? 'btn-soft' : 'btn-ghost'}`} onClick={useMyLocation} disabled={locating} style={{ border: 'none', height: 50 }}>
              <IconMapPin /> {locating ? 'Locating…' : coords ? 'Near you' : 'Use my location'}
            </button>
            <button className="btn btn-primary" style={{ height: 50 }} onClick={runSearch}>
              <IconSearch /> Search
            </button>
          </div>

          <div className="hero-stats">
            <div className="hs"><b>100%</b><span>Verified providers</span></div>
            <div className="hs"><b>{categories.length || '—'}</b><span>Service categories</span></div>
            <div className="hs"><b>Free</b><span>To browse & contact</span></div>
          </div>
        </div>
      </section>

      <div className="page">
        {/* Category quick filters */}
        {categories.length > 0 && (
          <div className="cat-scroll mb-16">
            <button className={`chip${categoryId === '' ? ' active' : ''}`} onClick={() => setCategoryId('')}>All</button>
            {categories.map((c) => (
              <button key={c._id} className={`chip${categoryId === c._id ? ' active' : ''}`} onClick={() => setCategoryId(c._id)}>{c.name}</button>
            ))}
          </div>
        )}

        <div className="section-head">
          <h2>{coords ? 'Providers near you' : 'Top-rated providers'}</h2>
          <div className="row gap-16">
            <div className="view-toggle" role="tablist" aria-label="Results view">
              <button
                className={`btn ${view === 'list' ? 'btn-primary' : 'btn-ghost'}`}
                aria-pressed={view === 'list'}
                onClick={() => setView('list')}
              >
                List
              </button>
              <button
                className={`btn ${view === 'map' ? 'btn-primary' : 'btn-ghost'}`}
                aria-pressed={view === 'map'}
                onClick={() => setView('map')}
              >
                <IconMapPin style={{ width: 16, height: 16 }} /> Map
              </button>
            </div>
            <div className="input-icon" style={{ width: 180 }}>
              <IconStar style={{ width: 16, height: 16 }} />
              <select className="select" value={minRating} onChange={(e) => setMinRating(e.target.value)} aria-label="Minimum rating">
                <option value="">Any rating</option>
                <option value="4">4★ & up</option>
                <option value="4.5">4.5★ & up</option>
                <option value="5">5★ only</option>
              </select>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-providers">
            {Array.from({ length: 6 }).map((_, i) => <ProviderCardSkeleton key={i} />)}
          </div>
        ) : providers.length === 0 ? (
          <div className="card card-pad">
            <EmptyState icon={<IconSearch />} title="No providers found">
              Try a different category or clear your filters. Verified providers appear here as they join.
            </EmptyState>
          </div>
        ) : view === 'map' ? (
          <ProvidersMap providers={providers} userCoords={coords} />
        ) : (
          <div className="grid grid-providers">
            {providers.map((p) => (
              <ProviderCard
                key={p._id}
                provider={p}
                favorited={fav.enabled ? fav.ids.has(p._id) : undefined}
                onToggleFavorite={fav.enabled ? fav.toggle : undefined}
              />
            ))}
          </div>
        )}

        {/* Trust strip */}
        <section className="section">
          <div className="grid grid-stats">
            {[
              { icon: <IconShieldCheck />, t: 'Verified pros', d: 'Every provider is ID-checked and document-verified before going live.' },
              { icon: <IconStar />, t: 'Real reviews', d: 'Ratings come only from customers who actually contacted the provider.' },
              { icon: <IconBolt />, t: 'Instant contact', d: 'Reveal a provider’s number or send a job request in one click.' },
              { icon: <IconUsers />, t: 'Local first', d: 'Search by distance to find pros who actually serve your area.' },
            ].map((f) => (
              <div key={f.t} className="card card-pad">
                <div className="empty-icon" style={{ margin: 0, width: 42, height: 42, color: 'var(--primary)', background: 'var(--primary-50)' }}>{f.icon}</div>
                <h3 style={{ fontSize: 16, margin: '12px 0 6px' }}>{f.t}</h3>
                <p className="muted small" style={{ margin: 0 }}>{f.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Provider CTA */}
        <section className="card card-pad" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap', background: 'linear-gradient(120deg, var(--primary-50), #fff)' }}>
          <div className="row gap-16">
            <div className="empty-icon" style={{ margin: 0, color: 'var(--primary)', background: '#fff' }}><IconBriefcase /></div>
            <div>
              <h3 style={{ fontSize: 18 }}>Are you a service provider?</h3>
              <p className="muted" style={{ margin: '4px 0 0' }}>Create a profile, get verified, and start receiving job requests.</p>
            </div>
          </div>
          <a href="/login" className="btn btn-primary">Join as a pro</a>
        </section>
      </div>
    </div>
  );
}
