import { useState, useEffect } from 'react';
import {
  adminApi, subscriptionsApi,
  type ProviderProfile, type VerificationDocument, type Category,
  type SubscriptionPlan, type JobStats, type RevenueMetrics, type User,
} from '../api/client';
import { useToast } from '../contexts/ToastContext';
import { providerName, currency, relativeTime, VERIFICATION_META } from '../lib/format';
import { Avatar, Field, PageLoader, EmptyState, Modal } from '../components/ui';
import {
  IconGrid, IconShieldCheck, IconDoc, IconTag, IconSparkle,
  IconBriefcase, IconDollar, IconUsers, IconCheck, IconX, IconPlus, IconTrending,
} from '../components/icons';

type Tab = 'overview' | 'providers' | 'documents' | 'categories' | 'plans';

const TABS: { key: Tab; label: string; icon: React.ReactNode }[] = [
  { key: 'overview', label: 'Overview', icon: <IconGrid /> },
  { key: 'providers', label: 'Providers', icon: <IconShieldCheck /> },
  { key: 'documents', label: 'Documents', icon: <IconDoc /> },
  { key: 'categories', label: 'Categories', icon: <IconTag /> },
  { key: 'plans', label: 'Plans', icon: <IconSparkle /> },
];

export default function Admin() {
  const [tab, setTab] = useState<Tab>('overview');
  return (
    <div className="page">
      <h1 className="page-title">Admin panel</h1>
      <p className="page-sub">Manage the marketplace.</p>
      <div className="tabs">
        {TABS.map((t) => (
          <button key={t.key} className={`tab${tab === t.key ? ' active' : ''}`} onClick={() => setTab(t.key)}>{t.icon} {t.label}</button>
        ))}
      </div>
      {tab === 'overview' && <Overview />}
      {tab === 'providers' && <Providers />}
      {tab === 'documents' && <Documents />}
      {tab === 'categories' && <Categories />}
      {tab === 'plans' && <Plans />}
    </div>
  );
}

/* ----------------------------------------------------------------- Overview */
function Overview() {
  const [jobs, setJobs] = useState<JobStats | null>(null);
  const [rev, setRev] = useState<RevenueMetrics | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      adminApi.jobStats().then(setJobs).catch(() => {}),
      adminApi.revenue().then(setRev).catch(() => {}),
      adminApi.users({ limit: 100 }).then(setUsers).catch(() => {}),
    ]).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageLoader />;

  const totalJobs = jobs ? Object.values(jobs).reduce((a, b) => a + b, 0) : 0;
  const providerCount = users.filter((u) => u.role === 'provider').length;
  const customerCount = users.filter((u) => u.role === 'customer').length;

  const cards = [
    { label: 'Total revenue', value: currency(rev?.totalRevenue ?? 0), icon: <IconDollar /> },
    { label: 'Active subscriptions', value: rev?.activeSubscriptions ?? 0, icon: <IconTrending /> },
    { label: 'Total jobs', value: totalJobs, icon: <IconBriefcase /> },
    { label: 'Users', value: users.length, icon: <IconUsers /> },
  ];

  return (
    <div className="stack gap-24">
      <div className="grid grid-stats">
        {cards.map((c) => (
          <div key={c.label} className="card stat">
            <div className="stat-label">{c.icon} {c.label}</div>
            <div className="stat-value">{c.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-2">
        <div className="card card-pad">
          <h2 style={{ fontSize: 17, marginBottom: 14 }}>Jobs by status</h2>
          {jobs && Object.keys(jobs).length > 0 ? (
            Object.entries(jobs).map(([status, count]) => (
              <div key={status} className="row between" style={{ padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ textTransform: 'capitalize' }}>{status}</span>
                <b>{count}</b>
              </div>
            ))
          ) : <p className="muted">No job data.</p>}
        </div>
        <div className="card card-pad">
          <h2 style={{ fontSize: 17, marginBottom: 14 }}>Community</h2>
          <div className="row between" style={{ padding: '8px 0', borderBottom: '1px solid var(--border)' }}><span>Providers</span><b>{providerCount}</b></div>
          <div className="row between" style={{ padding: '8px 0', borderBottom: '1px solid var(--border)' }}><span>Customers</span><b>{customerCount}</b></div>
          <div className="row between" style={{ padding: '8px 0' }}><span>Total subscriptions</span><b>{rev?.totalSubscriptions ?? 0}</b></div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------- Providers */
function Providers() {
  const toast = useToast();
  const [list, setList] = useState<ProviderProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => { adminApi.providers({ limit: 100 }).then(setList).catch(() => setList([])).finally(() => setLoading(false)); }, []);

  const verify = async (id: string, status: 'approved' | 'rejected') => {
    setBusy(id);
    try {
      const updated = await adminApi.verifyProvider(id, status);
      setList((prev) => prev.map((p) => (p._id === id ? { ...p, verificationStatus: updated.verificationStatus } : p)));
      toast.success(`Provider ${status}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not update');
    } finally { setBusy(null); }
  };

  if (loading) return <PageLoader />;
  if (list.length === 0) return <div className="card card-pad"><EmptyState icon={<IconShieldCheck />} title="No providers yet" /></div>;

  return (
    <div className="card card-pad">
      {list.map((p) => {
        const verif = VERIFICATION_META[p.verificationStatus];
        return (
          <div key={p._id} className="list-row">
            <Avatar name={providerName(p)} size="md" />
            <div className="lr-main">
              <div className="lr-title">{providerName(p)}</div>
              <div className="lr-sub">{p.serviceDescription ? p.serviceDescription.slice(0, 70) : 'No description'}</div>
            </div>
            <span className={`badge ${verif.cls}`}>{verif.label}</span>
            <div className="lr-actions">
              {p.verificationStatus !== 'approved' && (
                <button className="btn btn-success btn-sm" onClick={() => verify(p._id, 'approved')} disabled={busy === p._id}><IconCheck /> Approve</button>
              )}
              {p.verificationStatus !== 'rejected' && (
                <button className="btn btn-ghost btn-sm" onClick={() => verify(p._id, 'rejected')} disabled={busy === p._id}><IconX /> Reject</button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------- Documents */
function Documents() {
  const toast = useToast();
  const [list, setList] = useState<VerificationDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => { adminApi.verificationDocuments().then(setList).catch(() => setList([])).finally(() => setLoading(false)); }, []);

  const decide = async (id: string, status: 'approved' | 'rejected') => {
    setBusy(id);
    try {
      await adminApi.setDocumentStatus(id, status);
      setList((prev) => prev.filter((d) => d._id !== id));
      toast.success(`Document ${status}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not update');
    } finally { setBusy(null); }
  };

  if (loading) return <PageLoader />;
  if (list.length === 0) return <div className="card card-pad"><EmptyState icon={<IconDoc />} title="No pending documents" >Verification documents awaiting review will appear here.</EmptyState></div>;

  return (
    <div className="card card-pad">
      {list.map((d) => (
        <div key={d._id} className="list-row">
          <span className="empty-icon" style={{ margin: 0, width: 40, height: 40 }}><IconDoc /></span>
          <div className="lr-main">
            <div className="lr-title" style={{ textTransform: 'capitalize' }}>{d.documentType.replace(/_/g, ' ')}</div>
            <div className="lr-sub"><a href={d.documentUrl} target="_blank" rel="noreferrer">{d.documentUrl}</a> · {relativeTime(d.uploadedAt)}</div>
          </div>
          <div className="lr-actions">
            <button className="btn btn-success btn-sm" onClick={() => decide(d._id, 'approved')} disabled={busy === d._id}><IconCheck /> Approve</button>
            <button className="btn btn-ghost btn-sm" onClick={() => decide(d._id, 'rejected')} disabled={busy === d._id}><IconX /> Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}

/* --------------------------------------------------------------- Categories */
function Categories() {
  const toast = useToast();
  const [list, setList] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState<{ mode: 'create' | 'edit'; cat?: Category } | null>(null);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [saving, setSaving] = useState(false);

  const load = () => { adminApi.categories().then(setList).catch(() => setList([])).finally(() => setLoading(false)); };
  useEffect(load, []);

  const open = (mode: 'create' | 'edit', cat?: Category) => {
    setModal({ mode, cat });
    setName(cat?.name || '');
    setDesc(cat?.description || '');
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (modal?.mode === 'edit' && modal.cat) {
        const updated = await adminApi.updateCategory(modal.cat._id, { name: name.trim(), description: desc.trim() });
        setList((prev) => prev.map((c) => (c._id === updated._id ? updated : c)));
      } else {
        const created = await adminApi.createCategory({ name: name.trim(), description: desc.trim() || undefined });
        setList((prev) => [...prev, created]);
      }
      toast.success('Category saved');
      setModal(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not save');
    } finally { setSaving(false); }
  };

  if (loading) return <PageLoader />;

  return (
    <>
      <div className="between mb-16">
        <h2 style={{ fontSize: 17 }}>{list.length} categories</h2>
        <button className="btn btn-primary btn-sm" onClick={() => open('create')}><IconPlus /> New category</button>
      </div>
      <div className="card card-pad">
        {list.length === 0 ? <EmptyState icon={<IconTag />} title="No categories yet">Create the first service category.</EmptyState> : (
          list.map((c) => (
            <div key={c._id} className="list-row">
              <span className="empty-icon" style={{ margin: 0, width: 38, height: 38, color: 'var(--primary)', background: 'var(--primary-50)' }}><IconTag /></span>
              <div className="lr-main">
                <div className="lr-title">{c.name}</div>
                <div className="lr-sub">{c.description || 'No description'}</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={() => open('edit', c)}>Edit</button>
            </div>
          ))
        )}
      </div>

      {modal && (
        <Modal title={modal.mode === 'edit' ? 'Edit category' : 'New category'} onClose={() => setModal(null)}>
          <form onSubmit={save}>
            <Field label="Name" htmlFor="cname"><input id="cname" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Plumbing" required /></Field>
            <Field label="Description (optional)" htmlFor="cdesc"><textarea id="cdesc" className="textarea" value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} /></Field>
            <button className="btn btn-primary btn-block" disabled={saving}>{saving ? 'Saving…' : 'Save category'}</button>
          </form>
        </Modal>
      )}
    </>
  );
}

/* -------------------------------------------------------------------- Plans */
function Plans() {
  const toast = useToast();
  const [list, setList] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ name: '', price: '', leadLimit: '', durationDays: '', visibilityBoost: false });
  const [saving, setSaving] = useState(false);

  const load = () => { subscriptionsApi.plans().then(setList).catch(() => setList([])).finally(() => setLoading(false)); };
  useEffect(load, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const created = await adminApi.createPlan({
        name: form.name.trim(),
        price: Number(form.price),
        leadLimit: Number(form.leadLimit),
        durationDays: Number(form.durationDays),
        visibilityBoost: form.visibilityBoost,
      });
      setList((prev) => [...prev, created]);
      toast.success('Plan created');
      setModal(false);
      setForm({ name: '', price: '', leadLimit: '', durationDays: '', visibilityBoost: false });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not create plan');
    } finally { setSaving(false); }
  };

  if (loading) return <PageLoader />;

  return (
    <>
      <div className="between mb-16">
        <h2 style={{ fontSize: 17 }}>{list.length} plans</h2>
        <button className="btn btn-primary btn-sm" onClick={() => setModal(true)}><IconPlus /> New plan</button>
      </div>
      {list.length === 0 ? (
        <div className="card card-pad"><EmptyState icon={<IconSparkle />} title="No plans yet">Create subscription plans for providers.</EmptyState></div>
      ) : (
        <div className="grid grid-providers">
          {list.map((p) => (
            <div key={p._id} className={`card plan${p.visibilityBoost ? ' featured' : ''}`}>
              <div className="plan-name">{p.name}</div>
              <div className="plan-price">{currency(p.price)}<small> / {p.durationDays}d</small></div>
              <ul>
                <li><IconCheck /> {p.leadLimit} leads</li>
                <li><IconCheck /> {p.durationDays}-day duration</li>
                {p.visibilityBoost && <li><IconCheck /> Visibility boost</li>}
              </ul>
            </div>
          ))}
        </div>
      )}

      {modal && (
        <Modal title="New subscription plan" onClose={() => setModal(false)}>
          <form onSubmit={save}>
            <Field label="Plan name" htmlFor="pname"><input id="pname" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Pro" required /></Field>
            <div className="grid grid-2">
              <Field label="Price ($)" htmlFor="pprice"><input id="pprice" className="input" type="number" min={0} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required /></Field>
              <Field label="Duration (days)" htmlFor="pdur"><input id="pdur" className="input" type="number" min={1} value={form.durationDays} onChange={(e) => setForm({ ...form, durationDays: e.target.value })} required /></Field>
            </div>
            <Field label="Lead limit" htmlFor="plead"><input id="plead" className="input" type="number" min={0} value={form.leadLimit} onChange={(e) => setForm({ ...form, leadLimit: e.target.value })} required /></Field>
            <label className={`check-card${form.visibilityBoost ? ' sel' : ''}`} style={{ marginBottom: 16 }} onClick={() => setForm({ ...form, visibilityBoost: !form.visibilityBoost })}>
              <span className="tick">{form.visibilityBoost && <IconCheck />}</span>
              Visibility boost (priority placement)
            </label>
            <button className="btn btn-primary btn-block" disabled={saving}>{saving ? 'Creating…' : 'Create plan'}</button>
          </form>
        </Modal>
      )}
    </>
  );
}
