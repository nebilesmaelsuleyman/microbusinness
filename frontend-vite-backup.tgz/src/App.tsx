import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import type { Role } from './api/client';
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import ProviderProfile from './pages/ProviderProfile';
import MyJobs from './pages/MyJobs';
import Favorites from './pages/Favorites';
import ProviderDashboard from './pages/ProviderDashboard';
import ProviderProfileEdit from './pages/ProviderProfileEdit';
import Subscription from './pages/Subscription';
import Account from './pages/Account';
import Admin from './pages/Admin';

function Protected({ children, roles }: { children: React.ReactNode; roles?: Role[] }) {
  const { token, user } = useAuth();
  if (!token) return <Navigate to="/login" replace />;
  if (roles && user && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <>{children}</>;
}

export default function App() {
  const { token } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={token ? <Navigate to="/" replace /> : <Login />} />

      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="provider/:userId" element={<ProviderProfile />} />

        {/* Customer */}
        <Route path="my-jobs" element={<Protected roles={['customer', 'provider']}><MyJobs /></Protected>} />
        <Route path="favorites" element={<Protected roles={['customer']}><Favorites /></Protected>} />

        {/* Provider */}
        <Route path="dashboard" element={<Protected roles={['provider']}><ProviderDashboard /></Protected>} />
        <Route path="dashboard/profile" element={<Protected roles={['provider']}><ProviderProfileEdit /></Protected>} />
        <Route path="dashboard/subscription" element={<Protected roles={['provider']}><Subscription /></Protected>} />

        {/* Any authenticated user */}
        <Route path="account" element={<Protected><Account /></Protected>} />

        {/* Admin */}
        <Route path="admin" element={<Protected roles={['admin']}><Admin /></Protected>} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
